I am not the author of the original software, that person is Keith Harrison, who goes by "SiO2" on SourceForge:
https://sourceforge.net/u/sio2/profile/
My only contribution was to figure out how to use GLDirect on newer Windows versions (the instructions in this readme), and find a tiny bug that stopped GLDirect from being used the new way - a tiny change to the code (one line added, two removed).  It took well over a week of swearing and research and hunting around and battles with Windows and reading the source code to find the problems, change those three lines, and compile a new version, but that's besides the point.  I'm PeteyPak by the way, hi!

---

The file you want is opengl32.dll, it's in \bin\release\

Put it in the same folder as your .exe.  If you understood why you just did that, and it worked, you don't need to read any more.  Bye!

Otherwise...

--

There is too much text in this readme file. Sorry.  If you have to refer to it, then it's better to have too much here than not enough.

If you don't know what dlls are or how to use this software, jump to the explanation section at the bottom of this readme.

You may have trouble getting Windows to let you use GLDirect.  How do you know if GLDirect is being used?  When you see a file called "gldirect.log" appear next to the executable that you're trying to get GLDirect to work with.  If not - is it definitely OpenGL software?  If gldirect.log is appearing but something's not working right, look again - are you *sure* it's really not working?  What change were you expecting?
If you're sure GLDirect is being used but not working, read the contents of the log.  If the contents look legit but something's still not working right, put a copy of gldirect.ini in the folder with your exe and play with the settings, see if the log contents get better.  If you've done that and nothing seems to get it working right, or if the log flatly says something is broken (http://xkcd.com/722/), then you might just be out of luck.  See the explanation section at the bottom of this readme.

--

###### HOW TO USE GLDIRECT ######
There are nine circles of Hell in Dante's Inferno.  There are nine circles of dll-Hell described below.  How far you'll go, will depend on your version of Windows (be it 3.1, 95, 2000, 7, or 8, and be it x86 [meaning 32-bit] or x64 [meaning 64-bit]).  It will also depend on your sub-version of Windows (Professional vs. Business vs Home Office vs Personal vs Enterprise...), which service pack you have installed, which security updates you have installed, what global registry settings are used, the level of admin control on the default account you're using, the phase of the moon when your particular Windows installation occurred, and the capricious whim of the ancient Greek spirit who lives in the forest of one of the default desktop background images.  There is no simple rule to say what will work for you.

### The Vestibule of Hell ###
If this works for you, you don't need to enter Hell at all!
Drop the dll next to the executable you're using.  e.g.: I want to run
"C:\Program Files (x86)\Q3Arena\quake3.exe" via my TriDef software to run with a 3D monitor, so I put opengl32.dll in
"C:\Program Files (x86)\Q3Arena\".
and I run TriDef (which runs quake3.exe).  I don't put the dll in with Quake's other dlls, I don't put it in with TriDef.  If this does not work, you're entering Hell.

Try your software.  Did gldirect.log appear?  GLDirect is working!
No?

Leave the dll there for now...

### Limbo, the First Circle of Hell ###
Create a file (any file, eg: an empty new text file), and name it the same as your exe but with .local on the end, so in my example, I call it quake3.exe.local.  There are now at least three files in the folder: quake3.exe, quake3.exe.local, and opengl32.dll.  The .local file you just made does nothing itself, but it makes Windows behave differently.
Maybe.

Try your software.  Did gldirect.log appear?  GLDirect is working!
No?

### Lust, the Second Circle of Hell ###
Ugh.  Okay, delete the .local file.  Now make a directory instead, with the same name (quake3.exe.local).  Now try.  No?  What if you put the dll in that directory.  The official Microsoft documentation says that this is supposed to work.  You shouldn't have to reboot, but it might be worth trying.

Try your software.  Did gldirect.log appear?  GLDirect is working!
No?

If you have trouble with the instructions from here on in, or if you don't have experience with editing the Windows Registry, and if you don't have a full backup of your computer ready in case you break it so badly that it won't start up any more, then stop now.  Really - the third and fourth circles can break your machine completely and the seventh circle turns it into a frankenmonster even when it works.

### Gluttony, the Third Circle of Hell ###
Got a system backup?
Okaaaay.... Some Microsoft dude, here: http://blogs.msdn.com/b/junfeng/archive/2006/01/24/517221.aspx, said that in Windows Vista Beta 1 and beyond, there's a registry key that might be stopping this from working.  Find it and kill it.  The relevant quote:
[...] when the registry HKLM\Software\Microsoft\WindowsNT\CurrentVersion\Image File Execution Options!DevOverrideEnable:REG_DWORD is set to 1, DotLocal(.local) dll redirection will be enabled [...]
It's all confusing now, but .local redirection is good - it's what you're trying to do, so set that value to 1.  I'm using Win7 and I don't see that registry value at all, whether I use regedit.exe or regedt32.exe (note: no 'i' in the second one - it only exists on 64-bit operating systems).  I think it doesn't exist in Win7.
If you do find it though, try it.  If you find it in both editors, change both - try it all.
Reboot.

Try your software.  Did gldirect.log appear?  GLDirect is working!
No?

### Greed, the Fourth Circle of Hell ###
Fine, opengl.dll is a Windows "known dll".  You must be using a version of Windows where they decided to do some clever dll caching for performance reasons, then realised that it could be a "security feature" too, so they locked down any ability to use your own versions of "known dll"s.
Go into regedit, notice that known dlls are in 
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\KnownDLLs
and that opengl32.dll isn't one of them.
It's not important enough for a separate entry, it's lumped in with the entry called "DllDirectory32".  You really don't want to mess with that, leave it alone.  But if you go up one level, click on the 'Session Manager' folder, you'll see some registry keys on the right, and one of them is "ExcludeFromKnownDlls".  Edit that one, put "opengl32.dll" in there.  Reboot.

Try your software.  Did gldirect.log appear?  GLDirect is working!
No?

### Anger, the Fifth Circle of Hell ###
Why isn't this #$%^&*ing thing working!  It's supposed to work now!  All the instructions that I can find online and in all the official Microsoft documentation say that it should be working now!  Other people in online bulletin boards say that this is working for them but it's not working for me!  What a crock of %^&*!!!
### Heresy, the Sixth Circle of Hell ###
Maybe something's wrong with GLDirect?

### Violence, the Seventh Circle of Hell. ###
Please note that if you get to here, (I did), then you must be really desperate, and you are about to expose yourself to the last two circles of Hell from Dante's Inferno.  Look them up.  They are Eight-Fraud and Nine-Treachery, because you're opening a door that could potentially let viruses and hackers into your system.  It is not a good idea to do what you're about to do.

GLDirect will only work for 32-bit applications.
If you're using a 32-bit version of Windows, you'll see C:\Windows\System32.  Get in there.
If you're using a 64-bit version of Windows, you'll also see it - but it's actually the 64-bit system folder (I guess that the name is just a standard now).  You'll also see the folder SysWOW64 - *that's* the 32-bit Windows system folder.  Yes, really.
(WOW64 stands for *W*indows (32) *O*n *W*indows *64*).
To clarify:  If you see the SysWOW64 folder, go there, if you don't see it, go into System32.

In there, you'll find the original version of opengl32.dll.
You can't touch it.  You can't give yourself security permissions to touch it.  You can't get to it via a command prompt, and administrator-elevated command prompts or explorer windows won't help you.  You'll get "Access Denied" messages, even with administrator privileges.
These are all very carefully thought-out and sensible security precautions.
You're about to break them them...
Right-click -> Properties -> Security tab -> Advanced -> Owner -> Edit -> choose "Administrators" (replacing "TrustedInstaller").  [OK] your way all the way out.  All the way, don't stop at the properties window.  Now Right-click -> Properties -> Security tab again, and this time you can edit the regular security settings.  Give administrators full control over the file, and [OK] your way out of there again.
Now you can do things to the file.
DO NOT DELETE THE FILE - you will want it again some day.
Just rename it - add "-original" to the end or something.  Now copy in the GLDirect version of opengl32.dll.

Try your software.  Did gldirect.log appear?  GLDirect is working!
Yes!

If your software does anything at all besides crash, it *must* be using GLDirect, because it's not using the original opengl32.dll any more.  You *have* to be seeing the log file appear (unless you're also using the .ini and you've set the option to disable the log file for some reason).

You have now descended into hell and madness.

Enjoy!

 -- PeteyPak.






###### PRO-TIP ######
Run your Open-GL software at the same resolution as your display, it will be faster than rendering a smaller version.  The reason is that graphics cards are good at rendering large images.  Graphics cards are not good at rendering smaller images, and then also managing them as a bunch of pixels, and then rescaling them to an even bigger bunch of pixels (surprisingly computationally-expensive to do) before pushing them out.

 
 
 
 


###### EXPLANATION SECTION - What's going on exactly? ######
If you have this (GLDirect) at all, you probably already know why you have it, but just in case:
Your monitor is plugged into your graphics card.  Your graphics card is plugged into the motherboard, along with your CPU, RAM, etc.  Your CPU arranges data and instructions and sends them to your graphics card in different formats, then your graphics card takes those instructions (polygons, textures, lighting instructions, special effects like water and fog) and draws the pictures that the instructions describe.
A common format for sending those instructions is OpenGL - it's used a lot elsewhere but in the Windows world in games, it isn't used much any more.  You're probably here because you're trying to get an older (1990s) game to work.  In Windows, most games now use different dialects of DirectX instead.
Different graphics cards support different versions of DirectX with different features, and different versions of Windows will make sure that everything works regardless of the exact graphics card you have.  That's a good summary of what operating systems are for, by the way - they make sure that everything that the software asks for, works, regardless of what hardware you have.

Sometimes OpenGL won't work for you.  Maybe you have a dodgy graphics card, or you're running your game on an emulated machine, or you're playing your game via some wireless graphics protocol or something, and OpenGL isn't supported properly.

Sometimes OpenGL is just fine but you're trying to do something tricky.  For example, I have a 3D computer monitor and software (TriDef) to make 3D games *actually* 3D.  It is soooo much fun.  In my example, TriDef takes the DirectX instructions before they're sent to the graphics card, performs magic on them to make two views from slightly different angles, and sends two streams of graphics instructions instead of one, to generate two different views (one per eye) instead of one - that's how 3D works.
TriDef doesn't work with OpenGL, it only works with DirectX.

GLDirect saves the day!

When your software sends OpenGL instructions, Windows uses one of its standard libraries - opengl32.dll - to handle them.
GLDirect's version of opengl32.dll intercepts those OpenGL calls instead.  It sits in the middle and takes OpenGL commands and turns them into DirectX commands (Hence the name 'GLDirect' - catchier than OpenGLToDirectX).  For 98% of software, this works!  For 2% of software this totally barfs, sorry, there's only so much trickery that's possible.  It's not like translating one language into another, it's more like painting watercolours vs. making sand mandala patterns: Both things make coloured pictures, but they do not involve the same steps in the same order, and you do not prepare for them, or clean up after them, in the same way.

GLDirect has some settings that you can configure, you'll find them in gldirect.ini.  If you're fighting with some software that isn't quite working right, you can try altering those.
